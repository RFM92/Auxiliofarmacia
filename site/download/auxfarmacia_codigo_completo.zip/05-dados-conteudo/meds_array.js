const meds = [

      {
        id: "amox-clav-250", originalId: 1, nome: "Amox + Clavulanato (250 mg/5 mL)", classe: "Antibióticos", subclasse: "Penicilina + inibidor de beta-lactamase",
        indicacoes: ["otite", "sinusite", "infecção respiratória", "pele e tecidos moles"],
        conc: { valor: 50, unidade: "mg/mL", base: "amoxicilina" },
        status: "cautela", diferencial: "Amplia cobertura contra produtores de beta-lactamase; calcular pela amoxicilina.",
        alertas: ["Confirmar proporção amoxicilina:clavulanato da apresentação brasileira", "Usar no início da refeição reduz intolerância GI", "Ajustar em insuficiência renal", "Antimicrobiano: venda sob prescrição com retenção de receita no Brasil"],
        regimens: [{ rotulo: "Leve/moderada, 8/8h", tipo: "dia", min: 20, max: 40, unidade: "mg/kg/dia", tomas: 3, freq: "8/8h", maxDose: 500, maxDia: 1500, duracao: "7-10 dias", dias: [7, 10], idadeMinMeses: 2, memoria: "Dose expressa como amoxicilina; apresentações brasileiras informam amoxicilina + clavulanato." }],
        fontes: ["brAmoxClav", "anvisaAntimicrobianos"]
      },
      {
        id: "amoxicilina-250", originalId: 2, nome: "Amoxicilina Susp (250 mg/5 mL)", classe: "Antibióticos", subclasse: "Penicilina",
        indicacoes: ["otite", "faringite", "sinusite", "pneumonia", "infecção odontogênica"],
        conc: { valor: 50, unidade: "mg/mL", base: "amoxicilina" },
        status: "ok", diferencial: "Boa opção quando o alvo provável é sensível e não há necessidade de clavulanato.",
        alertas: ["Alergia a penicilina", "Mononucleose aumenta risco de exantema", "Ajustar em insuficiência renal", "Antimicrobiano: venda sob prescrição com retenção de receita no Brasil"],
        regimens: [{ rotulo: "Uso habitual dividido 8/8h", tipo: "dia", min: 25, max: 50, unidade: "mg/kg/dia", tomas: 3, freq: "8/8h", maxDose: 500, maxDia: 1500, duracao: "7-10 dias", dias: [7, 10] }],
        fontes: ["brAmoxicilina", "anvisaAntimicrobianos"]
      },
      {
        id: "azitromicina-200", originalId: 3, nome: "Azitromicina Susp (200 mg/5 mL)", classe: "Antibióticos", subclasse: "Macrolídeo",
        indicacoes: ["pneumonia atípica", "otite", "sinusite", "faringite alternativa"],
        conc: { valor: 40, unidade: "mg/mL", base: "azitromicina" },
        status: "cautela", diferencial: "Intervalo diário e curso curto; útil para atípicos, mas resistência pneumocócica limita uso empírico.",
        alertas: ["Risco de QT longo", "Checar interações", "Não é primeira linha para muitas infecções comuns"],
        regimens: [
          { rotulo: "Esquema 5 dias respiratório", tipo: "azitro5", min: 5, max: 10, unidade: "mg/kg/dose", tomas: 1, freq: "24/24h", maxDose: 500, duracao: "5 dias", dias: [5, 5], memoria: "D1 10 mg/kg; D2-D5 5 mg/kg." },
          { rotulo: "Sinusite/otite 3 dias", tipo: "dose", min: 10, max: 10, unidade: "mg/kg/dose", tomas: 1, freq: "24/24h", maxDose: 500, duracao: "3 dias", dias: [3, 3] }
        ],
        fontes: ["brAzitromicina", "anvisaAntimicrobianos"]
      },
      {
        id: "cefaclor-250", originalId: 4, nome: "Cefaclor Susp (250 mg/5 mL)", classe: "Antibióticos", subclasse: "Cefalosporina 2ª geração",
        indicacoes: ["otite", "sinusite", "infecção respiratória", "pele e tecidos moles"],
        conc: { valor: 50, unidade: "mg/mL", base: "cefaclor" },
        status: "ok", diferencial: "Cefalosporina oral; alternativa quando há indicação específica e sensibilidade provável.",
        alertas: ["Cautela em alergia grave a beta-lactâmicos", "Ajuste renal pode ser necessário"],
        regimens: [{ rotulo: "Uso habitual", tipo: "dia", min: 20, max: 40, unidade: "mg/kg/dia", tomas: 3, freq: "8/8h", maxDose: 500, maxDia: 1500, duracao: "7-10 dias", dias: [7, 10] }],
        fontes: ["anvisaBulario", "anvisaAntimicrobianos"]
      },
      {
        id: "cefalexina-250", originalId: 5, nome: "Cefalexina Susp (250 mg/5 mL)", classe: "Antibióticos", subclasse: "Cefalosporina 1ª geração",
        indicacoes: ["pele e tecidos moles", "faringite", "ITU baixa", "otite"],
        conc: { valor: 50, unidade: "mg/mL", base: "cefalexina" },
        status: "ok", diferencial: "Boa cobertura para estreptococos e MSSA; menos adequada para atípicos e alguns Gram-negativos.",
        alertas: ["Cautela em alergia grave a beta-lactâmicos", "Otite pode exigir dose diária maior"],
        regimens: [
          { rotulo: "Indicações gerais", tipo: "dia", min: 25, max: 50, unidade: "mg/kg/dia", tomas: 4, freq: "6/6h", maxDose: 500, maxDia: 2000, duracao: "7-14 dias", dias: [7, 14] },
          { rotulo: "Otite média", tipo: "dia", min: 75, max: 100, unidade: "mg/kg/dia", tomas: 4, freq: "6/6h", maxDose: 1000, maxDia: 4000, duracao: "7-10 dias", dias: [7, 10] }
        ],
        fontes: ["brCefalexina", "anvisaAntimicrobianos"]
      },
      {
        id: "cefixima-20", originalId: 6, nome: "Cefixima Susp (20 mg/mL)", classe: "Antibióticos", subclasse: "Cefalosporina 3ª geração oral",
        indicacoes: ["ITU", "otite", "sinusite", "faringite alternativa"],
        conc: { valor: 20, unidade: "mg/mL", base: "cefixima" },
        status: "cautela", diferencial: "Cefalosporina oral de espectro maior; preservar quando há boa alternativa mais estreita.",
        alertas: ["Ajuste renal", "Não cobre bem Staphylococcus aureus"],
        regimens: [{ rotulo: "Uso habitual", tipo: "dia", min: 8, max: 8, unidade: "mg/kg/dia", tomas: 1, freq: "24/24h ou dividir 12/12h", maxDose: 400, maxDia: 400, duracao: "7 dias", dias: [7, 7] }],
        fontes: ["anvisaBulario", "anvisaAntimicrobianos"]
      },
      {
        id: "cipro-50", originalId: 7, nome: "Ciprofloxacino Susp (50 mg/mL)", classe: "Antibióticos", subclasse: "Fluoroquinolona",
        indicacoes: ["ITU complicada", "infecção por Pseudomonas", "situações especiais"],
        conc: { valor: 50, unidade: "mg/mL", base: "ciprofloxacino" },
        status: "restrito", diferencial: "Reservar para indicações específicas; não é antibiótico pediátrico de rotina.",
        alertas: ["Uso pediátrico restrito", "Tendinopatia, QT e SNC", "Interage com leite, antiácidos, ferro e zinco"],
        regimens: [{ rotulo: "Situações específicas", tipo: "dose", min: 10, max: 20, unidade: "mg/kg/dose", tomas: 2, freq: "12/12h", maxDose: 750, maxDia: 1500, duracao: "7-10 dias", dias: [7, 10] }],
        fontes: ["anvisaBulario", "anvisaAntimicrobianos"]
      },
      {
        id: "claritro-250", originalId: 8, nome: "Claritromicina Susp (250 mg/5 mL)", classe: "Antibióticos", subclasse: "Macrolídeo",
        indicacoes: ["pneumonia atípica", "faringite alternativa", "sinusite alternativa"],
        conc: { valor: 50, unidade: "mg/mL", base: "claritromicina" },
        status: "cautela", diferencial: "Macrolídeo com mais interações CYP3A4 que azitromicina.",
        alertas: ["QT longo", "Muitas interações", "Ajuste em insuficiência renal importante"],
        regimens: [{ rotulo: "Uso habitual", tipo: "dose", min: 7.5, max: 7.5, unidade: "mg/kg/dose", tomas: 2, freq: "12/12h", maxDose: 500, maxDia: 1000, duracao: "7-10 dias", dias: [7, 10] }],
        fontes: ["anvisaBulario", "anvisaAntimicrobianos"]
      },
      {
        id: "eritro-250", originalId: 9, nome: "Eritromicina Susp (250 mg/5 mL)", classe: "Antibióticos", subclasse: "Macrolídeo",
        indicacoes: ["coqueluche", "faringite alternativa", "atípicos"],
        conc: { valor: 50, unidade: "mg/mL", base: "eritromicina" },
        status: "cautela", diferencial: "Macrolídeo mais antigo; maior intolerância gastrointestinal.",
        alertas: ["QT longo", "Interações", "Evitar automedicação em lactentes pequenos"],
        regimens: [{ rotulo: "Uso habitual", tipo: "dia", min: 30, max: 50, unidade: "mg/kg/dia", tomas: 4, freq: "6/6h", maxDose: 500, maxDia: 2000, duracao: "7-10 dias", dias: [7, 10] }],
        fontes: ["anvisaBulario", "anvisaAntimicrobianos"]
      },
      {
        id: "tmp-smx", originalId: 10, nome: "Sulfametoxazol + Trimetoprima", classe: "Antibióticos", subclasse: "Sulfonamida + inibidor de folato",
        indicacoes: ["ITU", "otite alternativa", "pneumocistose", "pele e tecidos moles"],
        conc: { valor: 8, unidade: "mg/mL", base: "trimetoprima (TMP); suspensão usual 40 mg TMP + 200 mg SMX/5 mL" },
        status: "cautela", diferencial: "A dose pediátrica costuma ser calculada pelo componente trimetoprima.",
        alertas: ["Contraindicado em menores de 2 meses", "Risco de rash grave e hipercalemia", "Checar função renal e interações"],
        regimens: [{ rotulo: "Uso usual por componente TMP", tipo: "dia", min: 6, max: 8, unidade: "mg TMP/kg/dia", tomas: 2, freq: "12/12h", maxDose: 160, maxDia: 320, duracao: "7-10 dias", dias: [7, 10], idadeMinMeses: 2, memoria: "Bulas brasileiras expressam a suspensão como 200 mg SMX + 40 mg TMP/5 mL e citam dose diária média aproximada de 6 mg TMP/kg/dia para esquemas usuais." }],
        fontes: ["brTmpSmx", "anvisaAntimicrobianos"]
      },
      {
        id: "cefalexina-500-alt", originalId: 51, adicionado: true, nome: "Cefuroxima axetil Susp (250 mg/5 mL)", classe: "Antibióticos", subclasse: "Cefalosporina 2ª geração",
        indicacoes: ["otite", "sinusite", "infecção respiratória"],
        conc: { valor: 50, unidade: "mg/mL", base: "cefuroxima" },
        status: "ok", diferencial: "Alternativa oral com cobertura respiratória; menos palatável em algumas formulações.",
        alertas: ["Tomar com alimento melhora absorção", "Cautela em alergia a beta-lactâmicos"],
        regimens: [{ rotulo: "Uso habitual", tipo: "dia", min: 20, max: 30, unidade: "mg/kg/dia", tomas: 2, freq: "12/12h", maxDose: 500, maxDia: 1000, duracao: "7-10 dias", dias: [7, 10] }],
        fontes: ["anvisaBulario", "anvisaAntimicrobianos"]
      },
      {
        id: "amoxicilina-400", originalId: 52, adicionado: true, nome: "Amoxicilina Susp alta concentração (400 mg/5 mL)", classe: "Antibióticos", subclasse: "Penicilina",
        indicacoes: ["otite", "sinusite", "pneumonia"],
        conc: { valor: 80, unidade: "mg/mL", base: "amoxicilina" },
        status: "ok", diferencial: "Mesma dose em mg, menor volume por tomada que 250 mg/5 mL.",
        alertas: ["Confirmar concentração do frasco", "Ajustar em insuficiência renal"],
        regimens: [{ rotulo: "Dose alta respiratória", tipo: "dia", min: 80, max: 90, unidade: "mg/kg/dia", tomas: 2, freq: "12/12h", maxDose: 1000, maxDia: 2000, duracao: "7-10 dias", dias: [7, 10] }],
        fontes: ["brAmoxicilina", "anvisaAntimicrobianos"]
      },

      {
        id: "diclofenaco-15", originalId: 11, nome: "Diclofenaco Resinato (15 mg/mL)", classe: "Analgésicos, antitérmicos e AINEs", subclasse: "AINE",
        indicacoes: ["dor", "inflamação"],
        conc: { valor: 15, unidade: "mg/mL", base: "diclofenaco" }, gotasMl: 20,
        status: "cautela", diferencial: "AINE com maior cautela gastrointestinal/renal; não é primeira escolha para febre simples.",
        alertas: ["Evitar em desidratação, doença renal, sangramento GI e suspeita de dengue", "Não associar a outro AINE"],
        regimens: [{ rotulo: "Dor/inflamação", tipo: "dose", min: 0.5, max: 1, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 50, maxDia: 150, duracao: "3-5 dias", dias: [3, 5] }],
        fontes: ["anvisaBulario"]
      },
      {
        id: "dipirona-500", originalId: 12, nome: "Dipirona Gotas (500 mg/mL)", classe: "Analgésicos, antitérmicos e AINEs", subclasse: "Analgésico/antitérmico",
        indicacoes: ["febre", "dor"],
        conc: { valor: 500, unidade: "mg/mL", base: "dipirona" }, gotasMl: 20,
        status: "cautela", diferencial: "1 mL = 20 gotas; em geral 1 gota tem 25 mg quando o frasco é 500 mg/mL.",
        alertas: ["Contraindicada em menores de 3 meses ou menos de 5 kg em bulas brasileiras", "Risco raro de agranulocitose e reações cutâneas graves"],
        regimens: [{ rotulo: "Febre/dor", tipo: "dose", min: 10, max: 20, unidade: "mg/kg/dose", tomas: 4, freq: "6/6h", maxDose: 1000, maxDia: 4000, duracao: "3-5 dias", dias: [3, 5], idadeMinMeses: 3, pesoMin: 5 }],
        fontes: ["brDipirona"]
      },
      {
        id: "ibuprofeno-100", originalId: 13, nome: "Ibuprofeno 100 mg/mL", classe: "Analgésicos, antitérmicos e AINEs", subclasse: "AINE",
        indicacoes: ["febre", "dor", "inflamação"],
        conc: { valor: 100, unidade: "mg/mL", base: "ibuprofeno" }, gotasMl: 10,
        status: "cautela", diferencial: "Em bulas brasileiras de gotas, a apresentação de 100 mg/mL costuma corresponder a 10 mg por gota; confirme o gotejador do fabricante.",
        alertas: ["Evitar antes de 6 meses sem orientação", "Evitar em desidratação, doença renal e suspeita de dengue", "Dose diária máxima usual 40 mg/kg/dia", "Não associar a outro AINE"],
        regimens: [{ rotulo: "Febre/dor", tipo: "dose", min: 5, max: 10, unidade: "mg/kg/dose", tomas: 4, freq: "6/6h a 8/8h", maxDose: 400, maxDiaKg: 40, duracao: "3-5 dias", dias: [3, 5], idadeMinMeses: 6 }],
        fontes: ["brIbuprofeno"]
      },
      {
        id: "ibuprofeno-200", originalId: 14, nome: "Ibuprofeno 200 mg/mL", classe: "Analgésicos, antitérmicos e AINEs", subclasse: "AINE",
        indicacoes: ["febre", "dor", "inflamação"],
        conc: { valor: 200, unidade: "mg/mL", base: "ibuprofeno" }, gotasMl: 20,
        status: "cautela", diferencial: "Concentração menos comum; mesma dose em mg gera metade do volume de 100 mg/mL. Confirme se a apresentação realmente existe e o fator de gotas do fabricante.",
        alertas: ["Alto risco de erro por concentração", "Evitar em desidratação, doença renal e suspeita de dengue", "Não associar a outro AINE"],
        regimens: [{ rotulo: "Febre/dor", tipo: "dose", min: 5, max: 10, unidade: "mg/kg/dose", tomas: 4, freq: "6/6h a 8/8h", maxDose: 400, maxDiaKg: 40, duracao: "3-5 dias", dias: [3, 5], idadeMinMeses: 6 }],
        fontes: ["brIbuprofeno"]
      },
      {
        id: "ibuprofeno-50", originalId: 15, nome: "Ibuprofeno 50 mg/mL", classe: "Analgésicos, antitérmicos e AINEs", subclasse: "AINE",
        indicacoes: ["febre", "dor", "inflamação"],
        conc: { valor: 50, unidade: "mg/mL", base: "ibuprofeno" }, gotasMl: 10,
        status: "cautela", diferencial: "Menor concentração; costuma gerar volumes maiores e mais fáceis de medir.",
        alertas: ["Evitar antes de 6 meses sem orientação", "Não associar a outro AINE", "Em bulas brasileiras, 50 mg/mL costuma equivaler a 5 mg por gota"],
        regimens: [{ rotulo: "Febre/dor", tipo: "dose", min: 5, max: 10, unidade: "mg/kg/dose", tomas: 4, freq: "6/6h a 8/8h", maxDose: 400, maxDiaKg: 40, duracao: "3-5 dias", dias: [3, 5], idadeMinMeses: 6 }],
        fontes: ["brIbuprofeno"]
      },
      {
        id: "nimesulida-50", originalId: 16, nome: "Nimesulida Gotas (50 mg/mL)", classe: "Analgésicos, antitérmicos e AINEs", subclasse: "AINE",
        indicacoes: ["dor", "inflamação"],
        conc: { valor: 50, unidade: "mg/mL", base: "nimesulida" }, gotasMl: 20,
        status: "restrito", diferencial: "No Brasil, bulas de nimesulida gotas indicam uso adulto e pediátrico acima de 12 anos; não é opção para criança pequena.",
        alertas: ["Contraindicada para menores de 12 anos em bulas brasileiras atuais", "Risco hepático", "Usar menor dose e menor tempo se prescrito", "Não usar como antitérmico isolado de rotina"],
        regimens: [{ rotulo: "Acima de 12 anos, sob prescrição", tipo: "dose", min: 1.5, max: 2.5, unidade: "mg/kg/dose", tomas: 2, freq: "12/12h", maxDose: 100, maxDiaKg: 5, duracao: "até 3 dias", dias: [3, 3], idadeMinMeses: 144 }],
        fontes: ["brNimesulida"]
      },
      {
        id: "paracetamol-200", originalId: 17, nome: "Paracetamol Gotas (200 mg/mL)", classe: "Analgésicos, antitérmicos e AINEs", subclasse: "Analgésico/antitérmico",
        indicacoes: ["febre", "dor"],
        conc: { valor: 200, unidade: "mg/mL", base: "paracetamol" }, gotasMl: 15,
        status: "ok", diferencial: "Bulas brasileiras de paracetamol gotas 200 mg/mL informam 14 a 16 gotas por mL; o painel usa 15 gotas/mL como aproximação e prioriza o volume em mL.",
        alertas: ["Cuidado em doença hepática", "Checar outros produtos com paracetamol", "Dose diária máxima pediátrica usual 75 mg/kg/dia", "Confirmar gotas/mL na bula do fabricante"],
        regimens: [{ rotulo: "Febre/dor", tipo: "dose", min: 10, max: 15, unidade: "mg/kg/dose", tomas: 4, freq: "6/6h", maxDose: 750, maxDiaKg: 75, duracao: "3-5 dias", dias: [3, 5] }],
        fontes: ["brParacetamol"]
      },

      {
        id: "betametasona-05", originalId: 18, nome: "Betametasona Gotas (0,5 mg/mL)", classe: "Alergia e corticoides", subclasse: "Corticoide sistêmico",
        indicacoes: ["alergia intensa", "asma/exacerbação", "inflamação"],
        conc: { valor: 0.5, unidade: "mg/mL", base: "betametasona" }, gotasMl: 20,
        status: "cautela", diferencial: "Corticoide potente; não comparar mg a mg com prednisolona.",
        alertas: ["Evitar uso repetido sem plano clínico", "Pode mascarar infecção", "Cautela em varicela, herpes e imunossupressão"],
        regimens: [{ rotulo: "Curto curso", tipo: "dia", min: 0.05, max: 0.1, unidade: "mg/kg/dia", tomas: 2, freq: "12/12h", maxDose: 2.5, maxDia: 5, duracao: "3-5 dias", dias: [3, 5] }],
        fontes: ["brBetametasona", "anvisaBulario"]
      },
      {
        id: "cetirizina-1", originalId: 19, nome: "Cetirizina Solução (1 mg/mL)", classe: "Alergia e corticoides", subclasse: "Anti-histamínico H1 2ª geração",
        indicacoes: ["rinite alérgica", "urticária", "prurido"],
        conc: { valor: 1, unidade: "mg/mL", base: "cetirizina" },
        status: "ok", diferencial: "Menos sedativa que anti-histamínicos de 1ª geração; no Brasil, soluções de 1 mg/mL costumam usar posologia por faixa etária.",
        alertas: ["Ajustar/avaliar em doença renal", "Pode causar sonolência em alguns pacientes", "Confirmar idade mínima da marca no Bulário da Anvisa"],
        regimens: [
          { rotulo: "Faixa etária habitual BR", tipo: "idade", unidade: "mg/dia", tomas: 2, freq: "12/12h ou 24/24h conforme idade", duracao: "7-14 dias", dias: [7, 14], bandas: [
            { minMeses: 24, maxMeses: 71, min: 5, max: 5, texto: "2-6 anos: 2,5 mg de 12/12h (5 mg/dia)." },
            { minMeses: 72, maxMeses: 143, min: 5, max: 10, texto: "6-12 anos: 5 a 10 mg/dia conforme bula/prescrição." },
            { minMeses: 144, maxMeses: 216, min: 10, max: 10, texto: "12 anos ou mais: 10 mg/dia." }
          ] }
        ],
        fontes: ["brCetirizina"]
      },
      {
        id: "desloratadina-05", originalId: 20, nome: "Desloratadina Xarope (0,5 mg/mL)", classe: "Alergia e corticoides", subclasse: "Anti-histamínico H1 2ª geração",
        indicacoes: ["rinite alérgica", "urticária"],
        conc: { valor: 0.5, unidade: "mg/mL", base: "desloratadina" },
        status: "ok", diferencial: "Metabólito ativo da loratadina; dose usual é fixa por idade.",
        alertas: ["Confirmar idade mínima da apresentação", "Cautela em doença hepática/renal"],
        regimens: [{ rotulo: "Faixa etária habitual", tipo: "idade", unidade: "mg/dia", freq: "24/24h", duracao: "7-14 dias", dias: [7, 14], bandas: [
          { minMeses: 6, maxMeses: 11, min: 1, max: 1, texto: "6-11 meses: 1 mg/dia." },
          { minMeses: 12, maxMeses: 71, min: 1.25, max: 1.25, texto: "1-5 anos: 1,25 mg/dia." },
          { minMeses: 72, maxMeses: 143, min: 2.5, max: 2.5, texto: "6-11 anos: 2,5 mg/dia." },
          { minMeses: 144, maxMeses: 216, min: 5, max: 5, texto: "12 anos ou mais: 5 mg/dia." }
        ] }],
        fontes: ["anvisaBulario"]
      },
      {
        id: "dexametasona-01", originalId: 21, nome: "Dexametasona Elixir (0,1 mg/mL)", classe: "Alergia e corticoides", subclasse: "Corticoide sistêmico",
        indicacoes: ["crupe", "asma/exacerbação", "alergia intensa"],
        conc: { valor: 0.1, unidade: "mg/mL", base: "dexametasona" },
        status: "cautela", diferencial: "Potente e longa duração; o volume pode ficar grande quando a concentração é 0,1 mg/mL.",
        alertas: ["Não usar cronicamente sem plano de retirada", "Pode mascarar infecção"],
        regimens: [
          { rotulo: "Crupe/asma - dose única", tipo: "dose", min: 0.15, max: 0.6, unidade: "mg/kg/dose", tomas: 1, freq: "dose única ou 24/24h", maxDose: 16, maxDia: 16, duracao: "1-2 dias", dias: [1, 2] },
          { rotulo: "Inflamação sistêmica", tipo: "dia", min: 0.02, max: 0.3, unidade: "mg/kg/dia", tomas: 3, freq: "8/8h", maxDia: 16, duracao: "conforme indicação", dias: [3, 5] }
        ],
        fontes: ["brDexametasona", "brPrednisolona"]
      },
      {
        id: "dexclorfeniramina", originalId: 22, nome: "Dexclorfeniramina Xarope", classe: "Alergia e corticoides", subclasse: "Anti-histamínico H1 1ª geração",
        indicacoes: ["rinite alérgica", "urticária", "prurido"],
        conc: { valor: 0.4, unidade: "mg/mL", base: "dexclorfeniramina" },
        status: "cautela", diferencial: "Mais sedativa e anticolinérgica que cetirizina/loratadina.",
        alertas: ["Sonolência, excitação paradoxal, boca seca", "Evitar em lactentes sem orientação"],
        regimens: [{ rotulo: "Alergia/prurido", tipo: "dose", min: 0.03, max: 0.06, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 2, maxDia: 12, duracao: "5-7 dias", dias: [5, 7] }],
        fontes: ["anvisaBulario"]
      },
      {
        id: "hidroxizina-2", originalId: 23, nome: "Hidroxizina Xarope (2 mg/mL)", classe: "Alergia e corticoides", subclasse: "Anti-histamínico H1 1ª geração",
        indicacoes: ["prurido", "urticária", "ansiedade/sedação sob prescrição"],
        conc: { valor: 2, unidade: "mg/mL", base: "hidroxizina" },
        status: "cautela", diferencial: "Útil para prurido com sedação; maior risco de sonolência que 2ª geração.",
        alertas: ["Sedação e efeito anticolinérgico", "Cautela com outros depressores do SNC e QT longo"],
        regimens: [{ rotulo: "Prurido/urticária", tipo: "dose", min: 0.5, max: 1, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 25, maxDia: 100, duracao: "5-7 dias", dias: [5, 7] }],
        fontes: ["anvisaBulario"]
      },
      {
        id: "loratadina-1", originalId: 24, nome: "Loratadina Xarope (1 mg/mL)", classe: "Alergia e corticoides", subclasse: "Anti-histamínico H1 2ª geração",
        indicacoes: ["rinite alérgica", "urticária"],
        conc: { valor: 1, unidade: "mg/mL", base: "loratadina" },
        status: "ok", diferencial: "Dose simples 1x/dia; em bulas brasileiras de xarope, crianças de 2 a 12 anos costumam ser estratificadas por peso corporal.",
        alertas: ["Doença hepática/renal pode exigir avaliação de dose", "Não exceder dose diária", "Uso pediátrico usual acima de 2 anos"],
        regimens: [{ rotulo: "Faixa por peso BR", tipo: "pesoFaixa", unidade: "mg/dose", tomas: 1, freq: "24/24h", duracao: "7-14 dias", dias: [7, 14], idadeMinMeses: 24, bandas: [
          { maxPeso: 30, min: 5, max: 5, texto: "2-12 anos com peso <30 kg: 5 mg 1x/dia." },
          { minPeso: 30.01, min: 10, max: 10, texto: "Peso ≥30 kg ou idade adulta/adolescente: 10 mg 1x/dia." }
        ] }],
        fontes: ["brLoratadina"]
      },
      {
        id: "prednisolona-3", originalId: 25, nome: "Prednisolona Solução (3 mg/mL)", classe: "Alergia e corticoides", subclasse: "Corticoide sistêmico",
        indicacoes: ["asma/exacerbação", "alergia intensa", "crupe alternativa"],
        conc: { valor: 3, unidade: "mg/mL", base: "prednisolona" },
        status: "cautela", diferencial: "Corticoide sistêmico de uso comum; dose diária varia por doença.",
        alertas: ["Evitar cursos repetidos sem reavaliação", "Pode elevar glicemia e pressão", "Uso prolongado exige retirada gradual"],
        regimens: [{ rotulo: "Curto curso respiratório/alérgico", tipo: "dia", min: 1, max: 2, unidade: "mg/kg/dia", tomas: 1, freq: "24/24h ou dividir 12/12h", maxDia: 40, duracao: "3-5 dias", dias: [3, 5] }],
        fontes: ["brPrednisolona"]
      },

      {
        id: "bromoprida-4", originalId: 26, nome: "Bromoprida Gotas (4 mg/mL)", classe: "Gastroenterologia e antieméticos", subclasse: "Antiemético/procinético",
        indicacoes: ["náuseas", "vômitos", "dispepsia sob prescrição"],
        conc: { valor: 4, unidade: "mg/mL", base: "bromoprida" }, gotasMl: 24,
        status: "cautela", diferencial: "Procinético com risco de reações extrapiramidais, especialmente em crianças.",
        alertas: ["Sonolência e sintomas extrapiramidais", "Evitar uso prolongado", "Cautela em obstrução/perfuração GI"],
        regimens: [{ rotulo: "Náuseas/vômitos", tipo: "dose", min: 0.05, max: 0.1, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 10, maxDia: 30, duracao: "até 3 dias", dias: [3, 3] }],
        fontes: ["bulaBromoprida"]
      },
      {
        id: "domperidona-1", originalId: 27, nome: "Domperidona Susp (1 mg/mL)", classe: "Gastroenterologia e antieméticos", subclasse: "Antiemético/procinético",
        indicacoes: ["náuseas", "vômitos", "gastroparesia sob prescrição"],
        conc: { valor: 1, unidade: "mg/mL", base: "domperidona" },
        status: "restrito", diferencial: "Dose por peso, mas com alerta de QT; usar pelo menor tempo e apenas quando indicado.",
        alertas: ["Risco de arritmia/QT longo", "Evitar com macrolídeos, azólicos e outros inibidores CYP3A4", "Revisar indicação em menores de 35 kg conforme bula local"],
        regimens: [{ rotulo: "Náuseas/vômitos", tipo: "dose", min: 0.2, max: 0.25, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 10, maxDiaKg: 1, maxDia: 30, duracao: "3-5 dias", dias: [3, 5] }],
        fontes: ["bulaDomperidona", "emaDomperidone"]
      },
      {
        id: "metoclopramida-4", originalId: 28, nome: "Metoclopramida Gotas (4 mg/mL)", classe: "Gastroenterologia e antieméticos", subclasse: "Antiemético/procinético",
        indicacoes: ["náuseas", "vômitos", "enxaqueca associada sob prescrição"],
        conc: { valor: 4, unidade: "mg/mL", base: "metoclopramida" }, gotasMl: 20,
        status: "restrito", diferencial: "Risco extrapiramidal em crianças; usar como segunda linha quando apropriado.",
        alertas: ["Evitar em menores de 1 ano", "Duração curta", "Suspender se sintomas neurológicos"],
        regimens: [{ rotulo: "Segunda linha", tipo: "dose", min: 0.1, max: 0.15, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 10, maxDiaKg: 0.5, maxDia: 30, duracao: "até 5 dias", dias: [3, 5], idadeMinMeses: 12 }],
        fontes: ["emaMetoclopramide"]
      },
      {
        id: "omeprazol-2", originalId: 29, nome: "Omeprazol Susp Magistral (2 mg/mL)", classe: "Gastroenterologia e antieméticos", subclasse: "Inibidor de bomba de prótons",
        indicacoes: ["DRGE", "esofagite", "proteção gástrica sob indicação"],
        conc: { valor: 2, unidade: "mg/mL", base: "omeprazol" },
        status: "ok", diferencial: "Melhor para supressão ácida sustentada; não é antiemético.",
        alertas: ["Reavaliar necessidade em uso prolongado", "Administrar antes de refeição quando possível"],
        regimens: [{ rotulo: "DRGE/esofagite", tipo: "dia", min: 0.7, max: 1.5, unidade: "mg/kg/dia", tomas: 1, freq: "24/24h", maxDia: 40, duracao: "15-30 dias", dias: [15, 30] }],
        fontes: ["fdaRanitidine", "msf"]
      },
      {
        id: "ondansetrona-2", originalId: 30, nome: "Ondansetrona Solução (2 mg/mL)", classe: "Gastroenterologia e antieméticos", subclasse: "Antagonista 5-HT3",
        indicacoes: ["náuseas", "vômitos", "gastroenterite sob protocolo", "quimioterapia"],
        conc: { valor: 2, unidade: "mg/mL", base: "ondansetrona" },
        status: "cautela", diferencial: "Menos extrapiramidal que metoclopramida, mas ainda exige atenção a QT e indicação.",
        alertas: ["QT longo e interações serotoninérgicas", "Ajuste/limite em insuficiência hepática grave", "Para gastroenterite, muitos protocolos usam dose única"],
        regimens: [{ rotulo: "Náuseas/vômitos", tipo: "dose", min: 0.1, max: 0.15, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h se prescrito", maxDose: 8, maxDia: 24, duracao: "até 3 dias", dias: [1, 3] }],
        fontes: ["dailyMedOndansetron"]
      },
      {
        id: "ranitidina-15", originalId: 31, nome: "Ranitidina Solução (15 mg/mL)", classe: "Gastroenterologia e antieméticos", subclasse: "Antagonista H2",
        indicacoes: ["DRGE legado", "úlcera legado"],
        conc: { valor: 15, unidade: "mg/mL", base: "ranitidina" },
        status: "restrito", diferencial: "Mantida no dashboard por existir no HTML original, mas substituída em muitos mercados por alerta de NDMA.",
        alertas: ["Não usar como opção ativa sem confirmar disponibilidade e bula local", "FDA solicitou retirada do mercado dos EUA em 2020", "Considerar alternativas como famotidina/IBP conforme avaliação"],
        regimens: [{ rotulo: "Legado - não preferencial", tipo: "dia", min: 4, max: 8, unidade: "mg/kg/dia", tomas: 2, freq: "12/12h", maxDose: 150, maxDia: 300, duracao: "15-30 dias", dias: [15, 30], bloqueado: true }],
        fontes: ["fdaRanitidine"]
      },
      {
        id: "simeticona-75", originalId: 32, nome: "Simeticona Gotas (75 mg/mL)", classe: "Gastroenterologia e antieméticos", subclasse: "Antifisético",
        indicacoes: ["gases", "distensão abdominal"],
        conc: { valor: 75, unidade: "mg/mL", base: "simeticona" }, gotasMl: 20,
        status: "ok", diferencial: "Ação local; dose costuma ser por idade/volume e não por efeito sistêmico.",
        alertas: ["Reavaliar dor abdominal persistente, vômitos biliosos, sangue ou distensão importante"],
        regimens: [{ rotulo: "Gases/distensão", tipo: "dose", min: 1, max: 3, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h se necessário", maxDose: 50, maxDia: 150, duracao: "até melhora", dias: [1, 3] }],
        fontes: ["msf"]
      },
      {
        id: "famotidina-8", originalId: 53, adicionado: true, nome: "Famotidina Susp (40 mg/5 mL)", classe: "Gastroenterologia e antieméticos", subclasse: "Antagonista H2",
        indicacoes: ["DRGE", "úlcera", "alternativa à ranitidina"],
        conc: { valor: 8, unidade: "mg/mL", base: "famotidina" },
        status: "ok", diferencial: "Alternativa H2 sem o alerta de NDMA da ranitidina citado pela FDA.",
        alertas: ["Ajustar em insuficiência renal", "Reavaliar necessidade de supressão ácida prolongada"],
        regimens: [{ rotulo: "DRGE/úlcera", tipo: "dose", min: 0.5, max: 1, unidade: "mg/kg/dose", tomas: 2, freq: "12/12h", maxDose: 20, maxDia: 40, duracao: "15-30 dias", dias: [15, 30] }],
        fontes: ["fdaRanitidine"]
      },
      {
        id: "lactulose", originalId: 54, adicionado: true, nome: "Lactulose Xarope (667 mg/mL)", classe: "Gastroenterologia e antieméticos", subclasse: "Laxativo osmótico",
        indicacoes: ["constipação"],
        conc: { valor: 667, unidade: "mg/mL", base: "lactulose" },
        status: "ok", diferencial: "Ajuste clínico pelo efeito evacuatório; pode causar gases/cólicas.",
        alertas: ["Aumentar água/fibras quando apropriado", "Reavaliar constipação com sinais de alarme"],
        regimens: [{ rotulo: "Constipação", tipo: "volumeKg", min: 0.5, max: 1, unidade: "mL/kg/dia", tomas: 1, freq: "24/24h ou dividir", duracao: "conforme resposta", dias: [3, 7] }],
        fontes: ["msf"]
      },
      {
        id: "sro", originalId: 55, adicionado: true, nome: "Sais de Reidratação Oral (SRO)", classe: "Gastroenterologia e antieméticos", subclasse: "Reidratação oral",
        indicacoes: ["diarreia", "vômitos", "desidratação leve/moderada"],
        conc: null,
        status: "ok", diferencial: "Intervenção central em gastroenterite; não é calculada em mg, e sim em mL/kg.",
        alertas: ["Sinais de desidratação grave exigem atendimento", "Oferecer em pequenos volumes frequentes se vomitar"],
        regimens: [{ rotulo: "Plano de reidratação", tipo: "volumeKg", min: 50, max: 100, unidade: "mL/kg em 4 horas", tomas: 1, freq: "fracionado", duracao: "4 horas e reavaliar", dias: [1, 1] }],
        fontes: ["msf"]
      },

      {
        id: "acebrofilina-5", originalId: 33, nome: "Acebrofilina Xarope (5 mg/mL)", classe: "Respiratório: mucolíticos, antitussígenos e broncodilatadores", subclasse: "Mucolítico/broncomodulador",
        indicacoes: ["tosse produtiva", "secreção brônquica"],
        conc: { valor: 5, unidade: "mg/mL", base: "acebrofilina" },
        status: "cautela", diferencial: "Uso e benefício variam por contexto; não substitui broncodilatador inalatório em crise.",
        alertas: ["Evitar automedicação em menores de 2 anos", "Reavaliar sibilância, dispneia ou febre persistente"],
        regimens: [{ rotulo: "Secreção brônquica", tipo: "dose", min: 0.5, max: 1, unidade: "mg/kg/dose", tomas: 2, freq: "12/12h", maxDose: 50, maxDia: 100, duracao: "5-7 dias", dias: [5, 7] }],
        fontes: ["msf"]
      },
      {
        id: "ambroxol-3", originalId: 34, nome: "Ambroxol Xarope (3 mg/mL)", classe: "Respiratório: mucolíticos, antitussígenos e broncodilatadores", subclasse: "Mucolítico",
        indicacoes: ["tosse produtiva", "secreção brônquica"],
        conc: { valor: 3, unidade: "mg/mL", base: "ambroxol" },
        status: "cautela", diferencial: "Mucolítico; hidratação e higiene nasal costumam ser medidas centrais.",
        alertas: ["Evitar em lactentes sem orientação", "Suspender se rash ou piora clínica"],
        regimens: [{ rotulo: "Secreção brônquica", tipo: "dose", min: 0.5, max: 1, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 30, maxDia: 90, duracao: "5-7 dias", dias: [5, 7] }],
        fontes: ["msf"]
      },
      {
        id: "carbocisteina-20", originalId: 35, nome: "Carbocisteína Xarope (20 mg/mL)", classe: "Respiratório: mucolíticos, antitussígenos e broncodilatadores", subclasse: "Mucolítico",
        indicacoes: ["tosse produtiva", "secreção brônquica"],
        conc: { valor: 20, unidade: "mg/mL", base: "carbocisteína" },
        status: "cautela", diferencial: "Mucolítico com uso variável por idade e formulação.",
        alertas: ["Evitar em menores de 2 anos sem orientação", "Cautela em úlcera péptica"],
        regimens: [{ rotulo: "Secreção brônquica", tipo: "dose", min: 2, max: 5, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 250, maxDia: 750, duracao: "5-7 dias", dias: [5, 7] }],
        fontes: ["msf"]
      },
      {
        id: "dropropizina-15", originalId: 36, nome: "Dropropizina Xarope (1,5 mg/mL)", classe: "Respiratório: mucolíticos, antitussígenos e broncodilatadores", subclasse: "Antitussígeno",
        indicacoes: ["tosse seca"],
        conc: { valor: 1.5, unidade: "mg/mL", base: "dropropizina" },
        status: "cautela", diferencial: "Antitussígeno para tosse seca; não usar para suprimir tosse produtiva importante.",
        alertas: ["Evitar em menores de 2 anos sem orientação", "Investigar dispneia, sibilância, febre ou tosse persistente"],
        regimens: [{ rotulo: "Tosse seca", tipo: "dose", min: 0.3, max: 0.6, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 15, maxDia: 45, duracao: "5-7 dias", dias: [5, 7] }],
        fontes: ["msf"]
      },
      {
        id: "hedera-7", originalId: 37, nome: "Hedera Helix Xarope (7 mg/mL)", classe: "Respiratório: mucolíticos, antitussígenos e broncodilatadores", subclasse: "Fitoterápico/expectorante",
        indicacoes: ["tosse produtiva", "secreção brônquica"],
        conc: { valor: 7, unidade: "mg/mL", base: "extrato de Hedera helix" },
        status: "cautela", diferencial: "Formulações fitoterápicas variam; confira concentração e padronização do extrato.",
        alertas: ["Cautela em crianças pequenas", "Reações GI e alérgicas podem ocorrer"],
        regimens: [{ rotulo: "Expectorante", tipo: "dose", min: 0.5, max: 1, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 35, maxDia: 105, duracao: "7 dias", dias: [7, 7] }],
        fontes: ["msf"]
      },
      {
        id: "levodropropizina-6", originalId: 38, nome: "Levodropropizina Xarope (6 mg/mL)", classe: "Respiratório: mucolíticos, antitussígenos e broncodilatadores", subclasse: "Antitussígeno",
        indicacoes: ["tosse seca"],
        conc: { valor: 6, unidade: "mg/mL", base: "levodropropizina" },
        status: "cautela", diferencial: "Antitussígeno periférico; separar de mucolíticos quando objetivo clínico diverge.",
        alertas: ["Evitar em tosse produtiva importante", "Cautela em insuficiência renal"],
        regimens: [{ rotulo: "Tosse seca", tipo: "dose", min: 1, max: 1, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 60, maxDia: 180, duracao: "5-7 dias", dias: [5, 7] }],
        fontes: ["msf"]
      },
      {
        id: "salbutamol-xarope-04", originalId: 39, nome: "Salbutamol Xarope (0,4 mg/mL)", classe: "Respiratório: mucolíticos, antitussígenos e broncodilatadores", subclasse: "Beta-2 agonista oral",
        indicacoes: ["broncoespasmo", "sibilância"],
        conc: { valor: 0.4, unidade: "mg/mL", base: "salbutamol" },
        status: "cautela", diferencial: "Via inalatória é preferida para broncoespasmo quando disponível e bem indicada.",
        alertas: ["Taquicardia, tremor e hipocalemia", "Crise respiratória exige avaliação", "Não tratar pneumonia/bronquiolite apenas com xarope"],
        regimens: [{ rotulo: "Broncoespasmo", tipo: "dose", min: 0.05, max: 0.1, unidade: "mg/kg/dose", tomas: 4, freq: "6/6h ou 8/8h", maxDose: 2, maxDia: 8, duracao: "5-7 dias", dias: [5, 7] }],
        fontes: ["msf"]
      },
      {
        id: "acetilcisteina-20", originalId: 56, adicionado: true, nome: "Acetilcisteína Xarope (20 mg/mL)", classe: "Respiratório: mucolíticos, antitussígenos e broncodilatadores", subclasse: "Mucolítico",
        indicacoes: ["secreção brônquica", "tosse produtiva"],
        conc: { valor: 20, unidade: "mg/mL", base: "acetilcisteína" },
        status: "cautela", diferencial: "Mucolítico; não substitui investigação de broncoespasmo, pneumonia ou aspiração.",
        alertas: ["Pode causar náusea e broncoespasmo em predispostos", "Evitar em lactentes sem orientação"],
        regimens: [{ rotulo: "Secreção brônquica", tipo: "dia", min: 10, max: 15, unidade: "mg/kg/dia", tomas: 3, freq: "8/8h", maxDia: 600, duracao: "5-7 dias", dias: [5, 7] }],
        fontes: ["msf"]
      },
      {
        id: "salbutamol-neb-5", originalId: 57, adicionado: true, nome: "Salbutamol Solução Nebulização (5 mg/mL)", classe: "Respiratório: mucolíticos, antitussígenos e broncodilatadores", subclasse: "Beta-2 agonista inalatório",
        indicacoes: ["broncoespasmo", "asma/exacerbação"],
        conc: { valor: 5, unidade: "mg/mL", base: "salbutamol" },
        status: "cautela", diferencial: "Entrega direta às vias aéreas; em crise, seguir protocolo de gravidade.",
        alertas: ["Taquicardia, tremor e hipocalemia", "Dispneia importante exige atendimento", "Diluição varia por nebulizador/protocolo"],
        regimens: [{ rotulo: "Nebulização", tipo: "dose", min: 0.1, max: 0.15, unidade: "mg/kg/dose", tomas: 1, freq: "conforme protocolo", maxDose: 5, maxDia: 20, duracao: "crise/reavaliação", dias: [1, 1] }],
        fontes: ["msf"]
      },

      {
        id: "aciclovir-40", originalId: 40, nome: "Aciclovir Susp (40 mg/mL)", classe: "Antivirais", subclasse: "Antiviral anti-herpes",
        indicacoes: ["varicela", "herpes simples", "herpes zoster"],
        conc: { valor: 40, unidade: "mg/mL", base: "aciclovir" },
        status: "cautela", diferencial: "Efeito depende de início precoce e indicação; hidratação reduz risco renal.",
        alertas: ["Ajustar em insuficiência renal", "Varicela em grupos de risco exige avaliação"],
        regimens: [{ rotulo: "Varicela/herpes", tipo: "dose", min: 20, max: 20, unidade: "mg/kg/dose", tomas: 4, freq: "6/6h", maxDose: 800, maxDia: 3200, duracao: "5-7 dias", dias: [5, 7] }],
        fontes: ["msf"]
      },
      {
        id: "oseltamivir-6", originalId: 58, adicionado: true, nome: "Oseltamivir Susp (6 mg/mL)", classe: "Antivirais", subclasse: "Inibidor de neuraminidase",
        indicacoes: ["influenza", "profilaxia influenza"],
        conc: { valor: 6, unidade: "mg/mL", base: "oseltamivir" },
        status: "cautela", diferencial: "Maior benefício quando iniciado cedo em influenza; dose é por faixa de peso.",
        alertas: ["Ajuste renal", "Náuseas/vômitos", "Seguir protocolo local para tratamento vs profilaxia"],
        regimens: [{ rotulo: "Tratamento influenza 5 dias", tipo: "pesoFaixa", unidade: "mg/dose", tomas: 2, freq: "12/12h", duracao: "5 dias", dias: [5, 5], bandas: [
          { maxPeso: 15, min: 30, max: 30, texto: "Até 15 kg: 30 mg 12/12h." },
          { minPeso: 15.01, maxPeso: 23, min: 45, max: 45, texto: ">15 a 23 kg: 45 mg 12/12h." },
          { minPeso: 23.01, maxPeso: 40, min: 60, max: 60, texto: ">23 a 40 kg: 60 mg 12/12h." },
          { minPeso: 40.01, min: 75, max: 75, texto: ">40 kg: 75 mg 12/12h." }
        ] }],
        fontes: ["cdcFlu"]
      },

      {
        id: "albendazol-40", originalId: 41, nome: "Albendazol Susp (40 mg/mL)", classe: "Antiparasitários", subclasse: "Benzimidazol",
        indicacoes: ["geo-helmintíases", "ascaridíase", "oxiuríase"],
        conc: { valor: 40, unidade: "mg/mL", base: "albendazol" },
        status: "ok", diferencial: "Muitas indicações usam dose fixa, não mg/kg.",
        alertas: ["Evitar no 1º trimestre de gestação", "Algumas parasitoses exigem esquemas específicos"],
        regimens: [{ rotulo: "Helmintíases comuns", tipo: "fixo", min: 400, max: 400, unidade: "mg/dose", tomas: 1, freq: "dose única", maxDose: 400, duracao: "1 dia; repetir conforme parasitose", dias: [1, 1] }],
        fontes: ["msf"]
      },
      {
        id: "mebendazol-20", originalId: 45, nome: "Mebendazol Susp (20 mg/mL)", classe: "Antiparasitários", subclasse: "Benzimidazol",
        indicacoes: ["oxiuríase", "ascaridíase", "ancilostomíase"],
        conc: { valor: 20, unidade: "mg/mL", base: "mebendazol" },
        status: "ok", diferencial: "Esquema clássico é fixo por dose; repetir em oxiúros pode ser necessário.",
        alertas: ["Confirmar parasitose e esquema", "Tratar contatos em oxiuríase conforme orientação"],
        regimens: [{ rotulo: "100 mg 12/12h por 3 dias", tipo: "fixo", min: 100, max: 100, unidade: "mg/dose", tomas: 2, freq: "12/12h", maxDose: 100, maxDia: 200, duracao: "3 dias", dias: [3, 3] }],
        fontes: ["msf"]
      },
      {
        id: "nitazoxanida-20", originalId: 46, nome: "Nitazoxanida Susp (20 mg/mL)", classe: "Antiparasitários", subclasse: "Antiprotozoário/anti-helmíntico",
        indicacoes: ["giardíase", "criptosporidiose", "diarreia parasitária"],
        conc: { valor: 20, unidade: "mg/mL", base: "nitazoxanida" },
        status: "ok", diferencial: "Dose por faixa etária em muitas bulas; administrar com alimento melhora tolerância.",
        alertas: ["Não é substituto de hidratação em diarreia", "Confirmar idade mínima e indicação"],
        regimens: [{ rotulo: "Faixa etária 3 dias", tipo: "idade", unidade: "mg/dose", tomas: 2, freq: "12/12h com alimento", duracao: "3 dias", dias: [3, 3], bandas: [
          { minMeses: 12, maxMeses: 47, min: 100, max: 100, texto: "1-3 anos: 100 mg 12/12h." },
          { minMeses: 48, maxMeses: 143, min: 200, max: 200, texto: "4-11 anos: 200 mg 12/12h." },
          { minMeses: 144, maxMeses: 216, min: 500, max: 500, texto: "12 anos ou mais: 500 mg 12/12h." }
        ] }],
        fontes: ["msf"]
      },
      {
        id: "pirantel-50", originalId: 48, nome: "Pirantel Susp (50 mg/mL)", classe: "Antiparasitários", subclasse: "Anti-helmíntico",
        indicacoes: ["oxiuríase", "ascaridíase"],
        conc: { valor: 50, unidade: "mg/mL", base: "pirantel" },
        status: "ok", diferencial: "Dose única por peso; oxiúros frequentemente requerem repetição e higiene ambiental.",
        alertas: ["Confirmar sal/base da formulação", "Cautela em doença hepática"],
        regimens: [{ rotulo: "Dose única", tipo: "dose", min: 10, max: 11, unidade: "mg/kg/dose", tomas: 1, freq: "dose única", maxDose: 1000, maxDia: 1000, duracao: "1 dia", dias: [1, 1] }],
        fontes: ["msf"]
      },

      {
        id: "fluconazol-10", originalId: 44, nome: "Fluconazol Susp (10 mg/mL)", classe: "Antifúngicos", subclasse: "Azólico sistêmico",
        indicacoes: ["candidíase oral", "candidíase esofágica", "infecção fúngica sob prescrição"],
        conc: { valor: 10, unidade: "mg/mL", base: "fluconazol" },
        status: "cautela", diferencial: "Boa biodisponibilidade oral; dose varia pelo sítio da candidíase.",
        alertas: ["Interações CYP", "Cautela hepática", "Doses de ataque podem ser necessárias em algumas indicações"],
        regimens: [{ rotulo: "Candidíase mucosa", tipo: "dia", min: 3, max: 6, unidade: "mg/kg/dia", tomas: 1, freq: "24/24h", maxDia: 400, duracao: "7-14 dias", dias: [7, 14] }],
        fontes: ["msf"]
      },
      {
        id: "nistatina-100k", originalId: 47, nome: "Nistatina Susp (100k UI/mL)", classe: "Antifúngicos", subclasse: "Polieno tópico/oral não absorvido",
        indicacoes: ["candidíase oral"],
        conc: { valor: 100000, unidade: "UI/mL", base: "nistatina" },
        status: "ok", diferencial: "Ação local na mucosa; manter contato com a boca antes de engolir quando indicado.",
        alertas: ["Higienizar bicos/chupetas quando pertinente", "Reavaliar se lesões persistem"],
        regimens: [{ rotulo: "Candidíase oral", tipo: "fixo", min: 100000, max: 200000, unidade: "UI/dose", tomas: 4, freq: "6/6h", maxDose: 200000, maxDia: 800000, duracao: "7-14 dias", dias: [7, 14] }],
        fontes: ["msf"]
      },

      {
        id: "cloreto-sodio-nasal", originalId: 42, nome: "Cloreto de Sódio 0,9% Nasal", classe: "Soluções e cuidados locais", subclasse: "Solução nasal",
        indicacoes: ["higiene nasal", "congestão nasal", "resfriado"],
        conc: { valor: 9, unidade: "mg/mL", base: "cloreto de sódio" }, gotasMl: 20,
        status: "ok", diferencial: "Uso local; não há alvo sistêmico mg/kg para a rotina de higiene nasal.",
        alertas: ["Aspirar com cuidado em lactentes", "Procurar avaliação se desconforto respiratório"],
        regimens: [{ rotulo: "Higiene nasal", tipo: "local", local: "1-2 gotas/jatos em cada narina, repetir conforme necessidade ou orientação.", freq: "4/4h a 6/6h", duracao: "indeterminado" }],
        fontes: ["msf"]
      },
      {
        id: "permetrina-5", originalId: 59, adicionado: true, nome: "Permetrina Loção 5%", classe: "Soluções e cuidados locais", subclasse: "Escabicida tópico",
        indicacoes: ["escabiose"],
        conc: null,
        status: "ok", diferencial: "Tratamento tópico; depende de aplicação correta e manejo de contatos/roupas.",
        alertas: ["Evitar olhos e mucosas", "Tratar contatos conforme orientação", "Coceira pode persistir após matar o parasita"],
        regimens: [{ rotulo: "Escabiose", tipo: "local", local: "Aplicar camada fina conforme bula/protocolo e repetir em 7 dias se indicado.", freq: "dose tópica", duracao: "8-14 h de contato, conforme produto" }],
        fontes: ["msf"]
      },

      {
        id: "ferro-polimaltosado-50", originalId: 43, nome: "Ferro Polimaltosado (50 mg/mL)", classe: "Vitaminas e suplementos", subclasse: "Ferro oral",
        indicacoes: ["anemia ferropriva", "profilaxia de deficiência de ferro"],
        conc: { valor: 50, unidade: "mg/mL", base: "ferro elementar" }, gotasMl: 20,
        status: "ok", diferencial: "Distinguir profilaxia de tratamento; dose é em ferro elementar.",
        alertas: ["Escurece fezes", "Manter fora do alcance de crianças", "Reavaliar hemoglobina/ferritina conforme plano"],
        regimens: [
          { rotulo: "Profilaxia", tipo: "dia", min: 1, max: 2, unidade: "mg/kg/dia", tomas: 1, freq: "24/24h", maxDia: 60, duracao: "3-6 meses", dias: [90, 180] },
          { rotulo: "Tratamento anemia", tipo: "dia", min: 3, max: 6, unidade: "mg/kg/dia", tomas: 1, freq: "24/24h", maxDia: 150, duracao: "3-6 meses", dias: [90, 180] }
        ],
        fontes: ["msf"]
      },
      {
        id: "vitamina-c-200", originalId: 49, nome: "Vitamina C Gotas (200 mg/mL)", classe: "Vitaminas e suplementos", subclasse: "Vitamina hidrossolúvel",
        indicacoes: ["suplementação", "escorbuto sob suspeita"],
        conc: { valor: 200, unidade: "mg/mL", base: "ácido ascórbico" }, gotasMl: 20,
        status: "ok", diferencial: "Rotina preventiva geralmente não exige doses altas.",
        alertas: ["Doses altas podem causar desconforto GI", "Cautela em litíase renal predisponente"],
        regimens: [{ rotulo: "Suplementação", tipo: "dia", min: 2, max: 5, unidade: "mg/kg/dia", tomas: 1, freq: "24/24h", maxDia: 500, duracao: "30-90 dias", dias: [30, 90] }],
        fontes: ["msf"]
      },
      {
        id: "vitamina-d-200ui", originalId: 50, nome: "Vitamina D Gotas (200 UI/gota)", classe: "Vitaminas e suplementos", subclasse: "Vitamina lipossolúvel",
        indicacoes: ["profilaxia deficiência vitamina D", "suplementação"],
        conc: { valor: 4000, unidade: "UI/mL", base: "colecalciferol; 20 gotas/mL" }, gotasMl: 20,
        status: "ok", diferencial: "Como cada gota tem 200 UI, 400 UI = 2 gotas; 1000 UI = 5 gotas.",
        alertas: ["Doses terapêuticas altas exigem controle", "Cautela com hipercalcemia e doença renal"],
        regimens: [{ rotulo: "Profilaxia/suplementação", tipo: "fixo", min: 400, max: 1000, unidade: "UI/dia", tomas: 1, freq: "24/24h", maxDia: 2000, duracao: "contínuo conforme risco", dias: [30, 30] }],
        fontes: ["msf"]
            },
      {
        id: "cetoprofeno-20", originalId: 60, nome: "Cetoprofeno Gotas (20 mg/mL)", classe: "Analgésicos, antitérmicos e AINEs", subclasse: "AINE - derivado do ácido propiônico",
        indicacoes: ["dor", "inflamação", "febre", "dor pós-operatória", "reumatismo"],
        conc: { valor: 20, unidade: "mg/mL", base: "cetoprofeno" }, gotasMl: 20,
        status: "cautela", diferencial: "AINE potente; útil em dor pós-operatória e processos inflamatórios. Gotejamento permite ajuste fino de dose.",
        alertas: ["Evitar em menores de 12 anos sem orientação", "Não associar a outro AINE ou corticoide", "Tomar com alimentos para reduzir irritação gástrica", "Contraindicado em úlcera péptica ativa", "Cautela em asmáticos (risco de broncoespasmo)"],
        regimens: [
          { rotulo: "Dor/inflamação leve a moderada", tipo: "dose", min: 0.5, max: 1, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 100, maxDiaKg: 3, duracao: "conforme resposta clínica", dias: [3, 7], idadeMinMeses: 72 },
          { rotulo: "Dor pós-operatória", tipo: "dose", min: 1, max: 2, unidade: "mg/kg/dose", tomas: 3, freq: "8/8h", maxDose: 200, maxDiaKg: 4, duracao: "3-5 dias", dias: [3, 5], idadeMinMeses: 144 }
        ],
        fontes: ["brCetoprofeno", "anvisa"]
      },
      {
        id: "cetorolaco-10", originalId: 61, nome: "Cetorolaco Trometamol (10 mg)", classe: "Analgésicos, antitérmicos e AINEs", subclasse: "AINE - derivado do ácido acético",
        indicacoes: ["dor aguda moderada a intensa", "dor pós-operatória", "cólica renal"],
        conc: { valor: 10, unidade: "mg/comprimido", base: "cetorolaco" }, comp: 1,
        status: "cautela", diferencial: "AINE com potente ação analgésica; uso limitado a 5 dias pelo risco de sangramento gastrointestinal e renal.",
        alertas: ["Uso máximo: 5 dias consecutivos", "Contraindicado em menores de 16 anos (risco aumentado de efeitos adversos)", "Evitar em insuficiência renal", "Risco de sangramento GI", "Não associar a anticoagulantes ou outro AINE"],
        regimens: [
          { rotulo: "Dor aguda", tipo: "dose", min: 10, max: 20, unidade: "mg/dose", tomas: 1, freq: "6/6h a 8/8h", maxDose: 40, maxDiaKg: 0.5, duracao: "máximo 5 dias", dias: [1, 5], idadeMinMeses: 192 }
        ],
        fontes: ["brCetorolaco", "anvisa"]
      }
    ]
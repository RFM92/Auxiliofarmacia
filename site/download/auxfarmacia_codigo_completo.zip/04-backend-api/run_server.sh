#!/bin/bash
cd /workspace/backend
exec ./venv/bin/python -m uvicorn api.main:app --host 0.0.0.0 --port 8000 --log-level info

#!/bin/bash
# ============================================
# Auxílio Farmácia Backend - Setup Script
# ============================================

set -e  # Para em caso de erro

echo "🚀 Auxílio Farmácia Backend - Setup"
echo "=============================="

# Verifica Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 não encontrado. Instale Python 3.11+ primeiro."
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "✅ Python $PYTHON_VERSION detectado"

# Cria virtualenv
if [ ! -d "venv" ]; then
    echo "📦 Criando virtual environment..."
    python3 -m venv venv
fi

# Ativa
source venv/bin/activate
echo "✅ Virtualenv ativado"

# Instala dependências
echo "📥 Instalando dependências..."
pip install --upgrade pip
pip install -r requirements.txt

# Copia .env
if [ ! -f ".env" ]; then
    echo "📝 Criando .env..."
    cp .env.example .env
    echo "⚠️  Edite o arquivo .env com suas credenciais reais"
fi

# Cria diretórios
mkdir -p uploads logs

# Inicializa banco
echo "🗄️  Inicializando banco de dados..."
python3 -c "
import asyncio
from api.database import init_db, close_db

async def setup():
    await init_db()
    print('✅ Banco criado')
    await close_db()

asyncio.run(setup())
"

echo ""
echo "=============================="
echo "✅ Setup concluído!"
echo ""
echo "Para rodar:"
echo "  source venv/bin/activate"
echo "  python run.py dev"
echo ""
echo "Acesse:"
echo "  API:    http://localhost:8000"
echo "  Docs:   http://localhost:8000/docs"
echo "  Admin:  http://localhost:8000/admin"
echo ""
echo "Login admin padrão:"
echo "  Email:    admin@auxfarmacia.com.br"
echo "  Senha:    admin123"
echo "  ⚠️  TROCAR EM PRODUÇÃO!"
echo ""

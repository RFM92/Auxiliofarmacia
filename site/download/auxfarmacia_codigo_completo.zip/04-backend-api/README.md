# 🚀 Auxílio Farmácia Backend

API completa para o Dashboard Pediátrico de Posologia - sistema de licenciamento, pagamentos, telemetria e gestão.

## 📋 Stack

- **FastAPI** - Framework web moderno e rápido
- **SQLAlchemy 2.0 async** - ORM
- **Pydantic 2** - Validação
- **SQLite/PostgreSQL** - Banco de dados
- **JWT** - Autenticação
- **Stripe + Asaas** - Pagamentos
- **SMTP/SendGrid** - Emails
- **Docker** - Deploy

## 🎯 Funcionalidades

### 1. Autenticação Completa
- ✅ Registro com validação
- ✅ Login com JWT
- ✅ Refresh token
- ✅ Verificação de email
- ✅ Reset de senha
- ✅ Blacklist de fraudadores

### 2. Sistema de Licenciamento
- ✅ 4 tiers: Free, Pro, Premium, Institutional
- ✅ 3 chaves demo embutidas
- ✅ Geração automática de chaves
- ✅ Ativação com fingerprint
- ✅ Limite de dispositivos
- ✅ Validação online
- ✅ Revogação administrativa
- ✅ Features granulares por tier

### 3. Pagamentos
- ✅ Stripe (cartão, boleto internacional)
- ✅ Asaas (PIX, boleto, cartão - BR)
- ✅ Webhooks para confirmação
- ✅ Geração automática de licença pós-pagamento
- ✅ Histórico de pagamentos

### 4. Telemetria
- ✅ Pageviews
- ✅ Eventos customizados (cálculos, visualizações, etc)
- ✅ Batch de eventos
- ✅ Detecção de device/browser/OS
- ✅ Sessões únicas
- ✅ Privacy-first (LGPD)

### 5. Anti-Pirataria
- ✅ Fingerprint de dispositivo (SHA-256)
- ✅ Limite de devices por licença
- ✅ Validação periódica
- ✅ Blacklist de usuários
- ✅ Detecção de fraude

### 6. Sistema de Email
- ✅ 6 templates prontos (welcome, verify, reset, license, payment, expiring)
- ✅ SMTP genérico
- ✅ SendGrid integration
- ✅ Anexos

### 7. Painel Admin
- ✅ Dashboard com métricas
- ✅ Gestão de usuários
- ✅ Gestão de licenças
- ✅ Gestão de pagamentos
- ✅ Telemetria em tempo real
- ✅ Blacklist/ban

## 🚀 Quick Start

### Opção 1: Local

```bash
# 1. Setup
cd backend
./setup.sh

# 2. Editar .env
nano .env

# 3. Rodar
source venv/bin/activate
python run.py dev
```

API rodando em: `http://localhost:8000`
Docs: `http://localhost:8000/docs`

### Opção 2: Docker

```bash
cd backend
docker-compose up -d
```

Inclui: API, PostgreSQL, Redis, Nginx, SSL-ready

## 📚 API Endpoints

### Auth
- `POST /api/auth/register` - Criar conta
- `POST /api/auth/login` - Login
- `POST /api/auth/refresh` - Renovar token
- `GET  /api/auth/me` - Dados do usuário
- `PUT  /api/auth/me` - Atualizar perfil
- `POST /api/auth/verify-email?token=...` - Verificar email
- `POST /api/auth/forgot-password?email=...` - Solicitar reset
- `POST /api/auth/reset-password?token=...&new_password=...` - Resetar

### Licenses
- `POST /api/licenses/activate` - Ativar chave
- `POST /api/licenses/validate` - Validar chave
- `POST /api/licenses/deactivate` - Desativar
- `GET  /api/licenses/my` - Minhas licenças
- `GET  /api/licenses/demo-keys` - Chaves demo

### Payments
- `POST /api/payments/create` - Criar pagamento
- `GET  /api/payments/my` - Meus pagamentos
- `POST /api/payments/webhook/stripe` - Webhook Stripe
- `POST /api/payments/webhook/asaas` - Webhook Asaas

### Telemetry
- `POST /api/telemetry/track` - 1 evento
- `POST /api/telemetry/batch` - Batch de eventos

### Admin (requer admin)
- `GET  /api/admin/stats` - Estatísticas
- `GET  /api/admin/users` - Listar usuários
- `PUT  /api/admin/users/{id}/role` - Mudar role
- `POST /api/admin/users/{id}/blacklist` - Bloquear
- `GET  /api/admin/licenses` - Listar licenças
- `POST /api/admin/licenses/create` - Criar licença
- `POST /api/admin/licenses/{key}/revoke` - Revogar
- `GET  /api/admin/payments` - Pagamentos
- `GET  /api/admin/telemetry/recent` - Eventos

## 🔑 Demo License Keys

```
Pro:         AUXFARMA-DEMO1-DEMO2-DEMO3-DEMO4
Premium:     AUXFARMA-DEMO5-DEMO6-DEMO7-DEMO8
Institutional: AUXFARMA-INST1-INST2-INST3-INST4
```

## 👤 Admin Padrão

```
Email:    admin@auxfarmacia.com.br
Senha:    admin123
```
⚠️ **TROCAR EM PRODUÇÃO!**

## 🧪 Testes

```bash
pytest tests/ -v
```

## 📦 Estrutura

```
backend/
├── api/
│   ├── main.py              # FastAPI app
│   ├── config.py            # Settings
│   ├── database.py          # SQLAlchemy
│   ├── dependencies.py      # Middleware
│   ├── schemas.py           # Pydantic
│   ├── models/              # DB models
│   │   ├── user.py
│   │   ├── license.py
│   │   ├── payment.py
│   │   └── telemetry.py
│   ├── routes/              # Endpoints
│   │   ├── auth.py
│   │   ├── licenses.py
│   │   ├── payments.py
│   │   ├── telemetry.py
│   │   └── admin.py
│   ├── services/            # Lógica
│   │   ├── license_service.py
│   │   ├── payment_service.py
│   │   └── email_service.py
│   └── utils/               # Helpers
│       ├── security.py
│       └── fingerprint.py
├── admin/                   # Frontend admin
│   └── index.html
├── emails/                  # Templates
│   ├── welcome.html
│   ├── verify.html
│   ├── reset_password.html
│   ├── license_activated.html
│   ├── payment_receipt.html
│   └── license_expiring.html
├── tests/                   # Testes
│   └── test_api.py
├── deploy/                  # Deploy configs
│   └── nginx.conf
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── .env.example
├── run.py
├── setup.sh
└── README.md
```

## 🔒 Segurança

- Senhas com **bcrypt** (12 rounds)
- **JWT** com HS256
- **CORS** configurável
- **Rate limiting** (30 req/s)
- **SQL injection** prevenido (SQLAlchemy)
- **Anti-pirataria**: fingerprint + device limit
- **LGPD**: telemetria privacy-first

## 📈 Métricas Admin

- Total de usuários
- Usuários ativos (24h, 7d)
- Licenças ativas
- Receita total / mensal
- Conversões
- Churn rate
- Top medicamentos
- Top calculadoras

## 🌐 Deploy em Produção

### Com Docker (recomendado)

```bash
# 1. Configurar .env
cp .env.example .env
nano .env

# 2. SSL com Let's Encrypt
mkdir -p deploy/certbot/conf deploy/certbot/www
docker run --rm -it \
  -v $(pwd)/deploy/certbot/conf:/etc/letsencrypt \
  -v $(pwd)/deploy/certbot/www:/var/www/certbot \
  certbot/certbot certonly --webroot \
  --webroot-path=/var/www/certbot \
  -d auxfarmacia.com.br -d www.auxfarmacia.com.br \
  --email admin@auxfarmacia.com.br \
  --agree-tos --no-eff-email

# 3. Subir
docker-compose up -d
```

### Sem Docker (systemd)

```bash
# Criar serviço
sudo nano /etc/systemd/system/auxfarmacia.service
```

```ini
[Unit]
Description=Auxílio Farmácia API
After=network.target

[Service]
Type=simple
User=auxfarmacia
WorkingDirectory=/opt/auxfarmacia
Environment="PATH=/opt/auxfarmacia/venv/bin"
ExecStart=/opt/auxfarmacia/venv/bin/uvicorn api.main:app --host 0.0.0.0 --port 8000 --workers 4
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable auxfarmacia
sudo systemctl start auxfarmacia
```

## 📞 Suporte

- Email: dev@auxfarmacia.com.br
- Issues: github.com/auxfarmacia/backend

---

**Feito com 💚 para pediatras brasileiros**

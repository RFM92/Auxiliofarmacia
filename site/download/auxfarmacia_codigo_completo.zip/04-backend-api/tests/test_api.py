"""
Tests para API Auxílio Farmácia
"""
import pytest
import asyncio
from httpx import AsyncClient
from fastapi.testclient import TestClient

# Importa o app
import sys
sys.path.insert(0, '/workspace/backend')

from api.main import app
from api.database import init_db, close_db, AsyncSessionLocal
from api.models import User, UserRole
from api.utils.security import hash_password


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(autouse=True)
async def setup_db():
    """Inicializa DB antes de cada teste"""
    await init_db()
    yield
    await close_db()


@pytest.mark.asyncio
async def test_health():
    """Test health check"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert "Auxílio Farmácia" in data["app"]


@pytest.mark.asyncio
async def test_api_info():
    """Test API info endpoint"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get("/api/info")
        assert response.status_code == 200
        data = response.json()
        assert "pro" in data["plans"]
        assert "premium" in data["plans"]
        assert data["plans"]["pro"]["price"] == 29.90


@pytest.mark.asyncio
async def test_register_login():
    """Test registro e login"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Register
        response = await client.post("/api/auth/register", json={
            "email": "test@auxfarmacia.com",
            "password": "Test1234!",
            "name": "Dr. Teste"
        })
        assert response.status_code == 201
        data = response.json()
        assert "access_token" in data
        assert data["user"]["email"] == "test@auxfarmacia.com"

        # Login
        response = await client.post("/api/auth/login", json={
            "email": "test@auxfarmacia.com",
            "password": "Test1234!"
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data


@pytest.mark.asyncio
async def test_register_duplicate_email():
    """Test que não permite emails duplicados"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        user_data = {
            "email": "duplicate@auxfarmacia.com",
            "password": "Test1234!",
            "name": "Dr. Teste"
        }
        # Primeira vez
        response = await client.post("/api/auth/register", json=user_data)
        assert response.status_code == 201

        # Segunda vez
        response = await client.post("/api/auth/register", json=user_data)
        assert response.status_code == 409


@pytest.mark.asyncio
async def test_license_validate_demo():
    """Test validação de chave demo"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/api/licenses/validate", json={
            "key": "AUXFARMA-DEMO1-DEMO2-DEMO3-DEMO4",
            "fingerprint": "abc123"
        })
        assert response.status_code == 200
        data = response.json()
        assert data["valid"] is True
        assert data["demo"] is True
        assert data["license"]["tier"] == "pro"


@pytest.mark.asyncio
async def test_license_validate_invalid():
    """Test chave inválida"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/api/licenses/validate", json={
            "key": "INVALID-KEY",
            "fingerprint": "abc123"
        })
        assert response.status_code == 200
        data = response.json()
        assert data["valid"] is False


@pytest.mark.asyncio
async def test_telemetry_track():
    """Test tracking de evento"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/api/telemetry/track", json={
            "session_id": "test_session_123",
            "event_type": "pageview",
            "path": "/dashboard",
            "data": {"page": "main"}
        })
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True


@pytest.mark.asyncio
async def test_telemetry_batch():
    """Test batch de eventos"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/api/telemetry/batch", json={
            "events": [
                {"session_id": "s1", "event_type": "calculation", "data": {"med": "paracetamol"}},
                {"session_id": "s1", "event_type": "medication_view", "data": {"med_id": "amoxicilina"}},
                {"session_id": "s1", "event_type": "calculator_use", "data": {"calculator": "PEWS"}},
            ]
        })
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["count"] == 3


@pytest.mark.asyncio
async def test_demo_keys_endpoint():
    """Test endpoint de chaves demo"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get("/api/licenses/demo-keys")
        assert response.status_code == 200
        data = response.json()
        assert len(data["demo_keys"]) == 3


@pytest.mark.asyncio
async def test_full_license_flow():
    """Test fluxo completo: register → admin cria licença → user ativa"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # 1. Register user
        response = await client.post("/api/auth/register", json={
            "email": "flow@auxfarmacia.com",
            "password": "Test1234!",
            "name": "Dr. Flow"
        })
        assert response.status_code == 201
        user_token = response.json()["access_token"]
        user_id = response.json()["user"]["id"]

        # 2. Admin login
        response = await client.post("/api/auth/login", json={
            "email": "admin@auxfarmacia.com.br",
            "password": "admin123"
        })
        assert response.status_code == 200
        admin_token = response.json()["access_token"]

        # 3. Admin cria licença
        response = await client.post(
            "/api/admin/licenses/create",
            json={
                "email": "flow@auxfarmacia.com",
                "tier": "pro",
                "duration_days": 30,
                "max_devices": 2
            },
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == 200
        license_key = response.json()["key"]

        # 4. User ativa licença
        response = await client.post(
            "/api/licenses/activate",
            json={
                "key": license_key,
                "fingerprint": "device_abc123"
            },
            headers={"Authorization": f"Bearer {user_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["license"]["tier"] == "pro"
        assert "calculadoras_avancadas" in data["features"] or "advanced_calculators" in str(data["features"])


@pytest.mark.asyncio
async def test_admin_stats():
    """Test endpoint de estatísticas admin"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Admin login
        response = await client.post("/api/auth/login", json={
            "email": "admin@auxfarmacia.com.br",
            "password": "admin123"
        })
        admin_token = response.json()["access_token"]

        # Get stats
        response = await client.get(
            "/api/admin/stats",
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "total_users" in data
        assert "active_licenses" in data
        assert "total_revenue" in data
        assert "churn_rate" in data


@pytest.mark.asyncio
async def test_unauthorized_admin_access():
    """Test que user comum não acessa endpoints admin"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        # Register regular user
        response = await client.post("/api/auth/register", json={
            "email": "regular@auxfarmacia.com",
            "password": "Test1234!",
            "name": "Dr. Regular"
        })
        user_token = response.json()["access_token"]

        # Tenta acessar admin
        response = await client.get(
            "/api/admin/stats",
            headers={"Authorization": f"Bearer {user_token}"}
        )
        assert response.status_code == 403


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

#!/bin/bash
# Keepalive: garante http server + cloudflared rodando, salva URL em /workspace/.tunnel_url
cd /workspace/output

ensure_httpd() {
  if ! pgrep -f "http.server 9090" > /dev/null; then
    (setsid python3 -m http.server 9090 --bind 0.0.0.0 < /dev/null > /tmp/httpd.log 2>&1 &)
    sleep 2
  fi
}

ensure_tunnel() {
  if ! pgrep -f "cloudflared tunnel" > /dev/null; then
    [ -x /tmp/cloudflared ] || { curl -sL --max-time 120 -o /tmp/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 && chmod +x /tmp/cloudflared; }
    (setsid /tmp/cloudflared tunnel --url http://localhost:9090 --no-autoupdate < /dev/null > /tmp/cloudflared.log 2>&1 &)
  fi
}

save_url() {
  URL=$(grep -o "https://[a-z0-9-]*\.trycloudflare\.com" /tmp/cloudflared.log 2>/dev/null | head -1)
  if [ -n "$URL" ]; then echo "$URL" > /workspace/.tunnel_url; fi
}

ensure_httpd
ensure_tunnel
sleep 12
save_url

# Loop de manutencao
while true; do
  sleep 30
  ensure_httpd
  ensure_tunnel
  save_url
done

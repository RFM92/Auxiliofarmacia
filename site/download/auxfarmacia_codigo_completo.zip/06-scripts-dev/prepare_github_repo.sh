#!/usr/bin/env bash
# ===================================================================
# Prepara o repositório GitHub do Auxílio Farmácia
#
#   ./scripts/prepare_github_repo.sh [destino]
#
# Cria a estrutura pronta para push, sem nenhum segredo.
# ===================================================================
set -euo pipefail

SRC="${SRC:-/workspace}"
DEST="${1:-$SRC/repo_github}"

echo "→ Preparando repositório em: $DEST"
mkdir -p "$DEST"/{site,api,scripts,.github/workflows}

# ---- frontend ----
echo "→ Copiando o frontend (site/)"
for f in "$SRC"/output/*.html "$SRC"/output/*.js "$SRC"/output/*.pdf "$SRC"/output/*.md; do
  [ -e "$f" ] || continue
  base="$(basename "$f")"
  case "$base" in
    debug*|test-*|diag-*|check-*|show-meds*|force-meds*|load.html|dashboard-FREE.html|dashboard-free-v2.html|VISUALIZAR.html) continue ;;
  esac
  cp "$f" "$DEST/site/$base"
done

# ---- backend ----
echo "→ Copiando o backend (api/)"
mkdir -p "$DEST/api/api"
cp -r "$SRC"/backend/api/*.py "$DEST/api/api/" 2>/dev/null || true
for d in models routes services utils; do
  [ -d "$SRC/backend/api/$d" ] && cp -r "$SRC/backend/api/$d" "$DEST/api/api/"
done
cp "$SRC"/backend/requirements.txt "$DEST/api/" 2>/dev/null || true
cp "$SRC"/backend/Dockerfile "$DEST/api/" 2>/dev/null || true
cp "$SRC"/backend/.env.example "$DEST/api/" 2>/dev/null || true
cp "$SRC"/backend/run.py "$DEST/api/" 2>/dev/null || true

# ---- scripts de auditoria ----
echo "→ Copiando os scripts de auditoria"
for s in "$SRC"/scripts/*.py "$SRC"/scripts/*.js; do
  [ -e "$s" ] || continue
  cp "$s" "$DEST/scripts/"
done

# ---- .github/workflows ----
# os workflows/README/etc. ja vem no destino quando DEST == SRC/repo_github
if [ "$DEST" != "$SRC/repo_github" ]; then
  if [ -d "$SRC/repo_github/.github/workflows" ]; then
    cp "$SRC"/repo_github/.github/workflows/*.yml "$DEST/.github/workflows/"
  fi
  for f in README.md LICENSE .gitignore GUIA_DEPLOY.md GUIA_ASAAS.md; do
    [ -e "$SRC/repo_github/$f" ] && cp "$SRC/repo_github/$f" "$DEST/"
  done
fi
[ -e "$DEST/GUIA_ASAAS.md" ] || cp "$SRC/output/GUIA_ASAAS.md" "$DEST/" 2>/dev/null || true

# ---- limpeza ----
echo "→ Limpando artefatos que não vão ao GitHub"
find "$DEST" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find "$DEST" -name "*.pyc" -delete 2>/dev/null || true
find "$DEST" -name ".env" -delete 2>/dev/null || true
find "$DEST" -name "*.db" -delete 2>/dev/null || true

echo ""
echo "✅ Repositório pronto em: $DEST"
echo ""
echo "Próximos passos:"
echo "  cd $DEST"
echo "  git init -b main"
echo "  git add . && git commit -m 'feat: Auxílio Farmácia v2026.08.1'"
echo "  git remote add origin https://github.com/SEU_USUARIO/auxilio-farmacia.git"
echo "  git push -u origin main"
echo ""
echo "Verificação de segurança:"
echo "  git ls-files | grep -E '\.env$|venv/|\.db$'   # deve estar vazio"
